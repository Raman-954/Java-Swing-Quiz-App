import java.util.HashMap;
import java.util.Map;

public class UserManager {
    // Simulating a database (Username -> Password)
    private static final Map<String, String> users = new HashMap<>();

    // Static block to add a default user for testing
    static {
        users.put("Raman", "123");
    }

    // Register a new user
    public static boolean register(String username, String password) {
        if (users.containsKey(username)) {
            return false; // User already exists
        }
        users.put(username, password);
        return true;
    }

    // Check login credentials
    public static boolean validate(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }

    // Update user credentials (Settings)
    public static void updateUser(String oldName, String newName, String newPass) {
        if (users.containsKey(oldName)) {
            users.remove(oldName);
            users.put(newName, newPass);
        }
    }
}